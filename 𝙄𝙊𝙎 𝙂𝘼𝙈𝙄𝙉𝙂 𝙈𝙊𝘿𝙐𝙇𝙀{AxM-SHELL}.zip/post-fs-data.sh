#!/system/bin/sh
MODDIR=${0%/*}

# Memberikan izin yang diperlukan
pm grant com.android.angle android.permission.WRITE_SECURE_SETTINGS
pm grant com.android.angle android.permission.READ_EXTERNAL_STORAGE
pm grant com.android.angle android.permission.WRITE_EXTERNAL_STORAGE
pm grant com.android.angle android.permission.POST_NOTIFICATIONS

# Mengizinkan aplikasi berjalan di latar belakang
cmd appops set com.android.angle RUN_IN_BACKGROUND allow
cmd appops set com.android.angle RUN_ANY_IN_BACKGROUND allow
cmd appops set com.android.angle START_FOREGROUND allow

# Memberikan izin wake lock (mencegah mode tidur)
cmd appops set com.android.angle WAKE_LOCK allow

# Mengizinkan akses penuh penyimpanan
cmd appops set com.android.angle MANAGE_EXTERNAL_STORAGE allow
cmd appops set com.android.angle LEGACY_STORAGE allow

# Mengizinkan perubahan pengaturan sistem
cmd appops set com.android.angle WRITE_SETTINGS allow

# Menolak izin akses statistik penggunaan (opsional)
cmd appops set com.android.angle GET_USAGE_STATS deny

chmod +x /data/adb/modules/IOS_DRIVER/service.sh
