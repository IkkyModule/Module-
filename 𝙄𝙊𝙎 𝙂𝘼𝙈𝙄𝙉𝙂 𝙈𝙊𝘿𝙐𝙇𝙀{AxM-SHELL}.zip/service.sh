#!/system/bin/sh
MODDIR=${0%/*}

# Pastikan aplikasi tetap berjalan di latar belakang
while true; do
    am startservice --user 0 -n com.android.angle/.MainService
    sleep 60
done

# Apply ANGLE GPU Settings
settings put global game_driver_opt_in_apps "$GAME_PACKAGES"
settings put global updatable_driver_production_opt_in_apps "$GAME_PACKAGES"
settings put global enable_gpu_debug_layers 1
settings put global force_hw_ui 1
settings put global angle_gl_driver_selection_angle egl

settings put system surface_flinger_use_frame_rate_api true 

# Aktifkan Angle Driver & Game Driver untuk game tertentu

settings put global angle_debug_package \
com.vega.alphafgl,com.garena.game.codm,com.levelinfinite.sgameGlobal,com.je.supersus,\
com.carxtech.sr,com.rockstargames.gtasa,com.rockstargames.gtalcs,com.rockstargames.gtavc,\
com.rockstargames.gtabycity,com.mojang.minecraftpe,com.mobile.legends,com.mobilelegends.hwag,\
com.mobilelegends.mi,com.dfjz.moba,com.miHoYo.GenshinImpact,com.dts.freefiremax,\
com.netmarble.sololv,com.dts.freefireth,com.tencent.ig,jp.konami.pesam,\
com.netease.newspike,com.HoYoverse.hsr.google,com.ea.gp.fifamobile,\
net.kdt.pojavlaunch,com.activision.callofduty.shooter,\
com.activision.callofduty.warzone,com.gamedevltd.wwh,com.galasports.totalfootball,\
com.pubg.krmobile,\ com.kurogame.wutheringwaves.global,\ com.craftsman.go,\
com.roblox.client,com.global.extremegames.arenabreakout,\ com.riotgames.league.wildrift,\
com.tencent.iglite,\ com.netease.dfjssea,\ com.garena.game.df,\ com.hermes.p6gameos,\ com.pixonic.wwr

settings put global angle_allowlist \
com.vega.alphafgl,com.garena.game.codm,com.levelinfinite.sgameGlobal,com.je.supersus,\
com.carxtech.sr,com.rockstargames.gtasa,com.rockstargames.gtalcs,com.rockstargames.gtavc,\
com.rockstargames.gtabycity,com.mojang.minecraftpe,com.mobile.legends,com.mobilelegends.hwag,\
com.mobilelegends.mi,com.dfjz.moba,com.miHoYo.GenshinImpact,com.dts.freefiremax,\
com.netmarble.sololv,com.dts.freefireth,com.tencent.ig,jp.konami.pesam,\
com.netease.newspike,com.HoYoverse.hsr.google,com.ea.gp.fifamobile,\
net.kdt.pojavlaunch,com.activision.callofduty.shooter,\
com.activision.callofduty.warzone,com.gamedevltd.wwh,com.galasports.totalfootball,\
com.pubg.krmobile,\ com.kurogame.wutheringwaves.global,\ com.craftsman.go,\
com.roblox.client,com.global.extremegames.arenabreakout,\ com.riotgames.league.wildrift,\
com.tencent.iglite,\ com.netease.dfjssea,\ com.garena.game.df,\ com.hermes.p6gameos,\ com.pixonic.wwr

settings put global updatable_driver_production_opt_in_apps \
com.vega.alphafgl,com.garena.game.codm,com.levelinfinite.sgameGlobal,com.je.supersus,\
com.carxtech.sr,com.rockstargames.gtasa,com.rockstargames.gtalcs,com.rockstargames.gtavc,\
com.rockstargames.gtabycity,com.mojang.minecraftpe,com.mobile.legends,com.mobilelegends.hwag,\
com.mobilelegends.mi,com.dfjz.moba,com.miHoYo.GenshinImpact,com.dts.freefiremax,\
com.netmarble.sololv,com.dts.freefireth,com.tencent.ig,jp.konami.pesam,\
com.netease.newspike,com.HoYoverse.hsr.google,com.ea.gp.fifamobile,\
net.kdt.pojavlaunch,com.activision.callofduty.shooter,\
com.activision.callofduty.warzone,com.gamedevltd.wwh,com.galasports.totalfootball,\
com.pubg.krmobile,\ com.kurogame.wutheringwaves.global,\ com.craftsman.go,\
com.roblox.client,com.global.extremegames.arenabreakout,\ com.riotgames.league.wildrift,\
com.tencent.iglite,\ com.netease.dfjssea,\ com.garena.game.df,\ com.hermes.p6gameos,\ com.pixonic.wwr

settings put global game_driver_opt_in_apps \
com.vega.alphafgl,com.garena.game.codm,com.levelinfinite.sgameGlobal,com.je.supersus,\
com.carxtech.sr,com.rockstargames.gtasa,com.rockstargames.gtalcs,com.rockstargames.gtavc,\
com.rockstargames.gtabycity,com.mojang.minecraftpe,com.mobile.legends,com.mobilelegends.hwag,\
com.mobilelegends.mi,com.dfjz.moba,com.miHoYo.GenshinImpact,com.dts.freefiremax,\
com.netmarble.sololv,com.dts.freefireth,com.tencent.ig,jp.konami.pesam,\
com.netease.newspike,com.HoYoverse.hsr.google,com.ea.gp.fifamobile,\
net.kdt.pojavlaunch,com.activision.callofduty.shooter,\
com.activision.callofduty.warzone,com.gamedevltd.wwh,com.galasports.totalfootball,\
com.pubg.krmobile,\ com.kurogame.wutheringwaves.global,\ com.craftsman.go,\
com.roblox.client,com.global.extremegames.arenabreakout,\ com.riotgames.league.wildrift,\
com.tencent.iglite,\ com.netease.dfjssea,\ com.garena.game.df,\ com.hermes.p6gameos,\ com.pixonic.wwr